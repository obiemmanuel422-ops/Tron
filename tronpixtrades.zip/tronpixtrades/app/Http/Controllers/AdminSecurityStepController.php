<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\SecurityStep;
use Illuminate\Http\Request;

class SecurityStepController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('can:admin'); // Only admins can access
    }

    // List all steps by type
    public function index(Request $request)
    {
        $type = $request->query('type', 'bank');
        return SecurityStep::where('type', $type)->orderBy('id')->get();
    }

    // Create new step
    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'explanation' => 'required|string',
            'code' => 'required|string|size:6',
            'account' => 'required|string|max:255',
            'type' => 'required|in:bank,broker',
        ]);

        return SecurityStep::create($validated);
    }

    // Update step
    public function update(Request $request, SecurityStep $securityStep)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'explanation' => 'required|string',
            'code' => 'required|string|size:6',
            'account' => 'required|string|max:255',
            'type' => 'required|in:bank,broker',
        ]);

        $securityStep->update($validated);
        return $securityStep;
    }

    // Delete step
    public function destroy(SecurityStep $securityStep)
    {
        $securityStep->delete();
        return response()->noContent();
    }
}