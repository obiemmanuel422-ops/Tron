<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Wallet;
use App\Models\Transaction;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use App\Mail\FundsCredited;
use App\Mail\FundsDebited;
use Inertia\Inertia;

class AdminTransactionController extends Controller
{
    /**
     * Ensure a user has a wallet in the given currency
     */
    protected function ensureWallet(User $user, string $currency = 'USD'): Wallet
    {
        return $user->wallets()->firstOrCreate(
            ['currency' => $currency],
            [
                'balance' => 0,
                'available_balance' => 0,
                'locked_balance' => 0,
            ]
        );
    }

    /**
     * Show credit/debit form for admins
     */
    public function index()
    {
        $this->authorizeAdmin();

        $users = User::all(['id', 'name', 'email']);

        return Inertia::render('Admin/Transactions', [
            'users' => $users,
        ]);
    }

    /**
     * Credit user wallet
     */
    public function credit(Request $request)
    {
        $this->authorizeAdmin();

        $data = $request->validate([
            'email' => 'required|email',
            'amount' => 'required|numeric|min:0.01',
            'currency' => 'string|nullable',
            'description' => 'string|nullable',
        ]);

        $user = User::where('email', $data['email'])->firstOrFail();

        $currency = $data['currency'] ?? 'USD';

        DB::transaction(function () use ($user, $data, $currency, &$transaction) {
            $wallet = $this->ensureWallet($user, $currency);
            $wallet->balance += $data['amount'];
            $wallet->available_balance += $data['amount'];
            $wallet->save();

            $transaction = Transaction::create([
                'user_id' => $user->id,
                'wallet_id' => $wallet->id,
                'type' => 'credit',
                'status' => 'completed',
                'amount' => $data['amount'],
                'currency' => $currency,
                'description' => $data['description'] ?? 'Admin credit',
            ]);
        });

        // send email (do not break flow if mail fails)
        try {
            Mail::to($user->email)->send(new FundsCredited($transaction));
        } catch (\Exception $e) {
            // Log $e if needed
        }

        // Redirect back to admin page with success
        return redirect()->back()->with('success', 'Wallet credited successfully.');
    }

    /**
     * Deduct from user wallet
     */
    public function deduct(Request $request)
    {
        $this->authorizeAdmin();

        $data = $request->validate([
            'email' => 'required|email',
            'amount' => 'required|numeric|min:0.01',
            'currency' => 'string|nullable',
            'description' => 'string|nullable',
        ]);

        $user = User::where('email', $data['email'])->firstOrFail();
        $currency = $data['currency'] ?? 'USD';

        DB::transaction(function () use ($user, $data, $currency, &$transaction) {
            $wallet = $this->ensureWallet($user, $currency);

            if ($wallet->available_balance < $data['amount']) {
                abort(400, 'Insufficient funds');
            }

            $wallet->balance -= $data['amount'];
            $wallet->available_balance -= $data['amount'];
            $wallet->save();

            $transaction = Transaction::create([
                'user_id' => $user->id,
                'wallet_id' => $wallet->id,
                'type' => 'debit',
                'status' => 'completed',
                'amount' => $data['amount'],
                'currency' => $currency,
                'description' => $data['description'] ?? 'Admin deduction',
            ]);
        });

        try {
            Mail::to($user->email)->send(new FundsDebited($transaction));
        } catch (\Exception $e) {
            // ignore mail errors
        }

        return redirect()->back()->with('success', 'Wallet debited successfully.');
    }

    /**
     * Check if current user is admin
     */
    protected function authorizeAdmin()
    {
        $actor = auth()->user();
        if (! $actor || ! method_exists($actor, 'isAdmin') || ! $actor->isAdmin()) {
            abort(403, 'Unauthorized');
        }
    }
}