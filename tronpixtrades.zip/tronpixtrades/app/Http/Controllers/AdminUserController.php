<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;

class AdminUserController extends Controller
{
    /**
     * List users for admin panel.
     *
     * Supports optional type filtering: ?type=bank|broker|admin
     */
    public function index(Request $request)
    {
        $this->authorizeAction($request);

        $type = $request->query('type'); // bank|broker|admin|null

        $query = User::query()->with('wallets');

        if ($type) {
            $query->where('account_type', $type);
        }

        // Limit to 200 users, ordered by newest
        $users = $query->latest()->take(200)->get()->map(function ($u) {
            $balance = $u->wallets->sum(fn($w) => (float) $w->balance); // short arrow function

            return [
                'id' => $u->id,
                'name' => $u->name,
                'email' => $u->email,
                'balance' => number_format($balance, 2),
                'joined' => $u->created_at?->toDateString(), // null-safe operator
                'status' => $u->is_active ?? true ? 'active' : 'inactive', // dynamic status if available
                'account_type' => $u->account_type, // include type for frontend
            ];
        });

        return response()->json(['data' => $users]);
    }

    /**
     * Ensure the current user is an admin.
     */
    protected function authorizeAction(Request $request)
    {
        $actor = $request->user();

        if (! $actor || ! method_exists($actor, 'isAdmin') || ! $actor->isAdmin()) {
            abort(403, 'Unauthorized');
        }
    }
}