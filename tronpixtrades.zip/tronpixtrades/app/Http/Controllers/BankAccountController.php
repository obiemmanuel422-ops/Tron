<?php

namespace App\Http\Controllers;

use Inertia\Inertia;
use Illuminate\Http\Request;

class BankAccountController extends Controller
{
    public function index(Request $request)
    {
        $user = $request->user();

        $accounts = $user->bankAccounts()->get();

        $totalBalance = $accounts->sum('balance');

        return Inertia::render('Dashboard/Home', [
            'totalBalance' => $totalBalance,
            'accounts' => $accounts,
            'notificationsCount' => 1, // replace later
            'featuredMarket' => [], // market composable still handles this
        ]);
    }
}