<?php

namespace App\Http\Controllers;

use Inertia\Inertia;
use Illuminate\Http\Request;

class BrokerAccountController extends Controller
{
    public function index(Request $request)
    {
        $user = $request->user();

        // Fetch the user's broker accounts
        $accounts = $user->brokerAccounts()->where('is_active', true)->get();

        $totalBalance = $accounts->sum('balance');

        return Inertia::render('Dashboard/Home', [
            'totalBrokerBalance' => $totalBalance,
            'brokerAccounts' => $accounts,
            'notificationsCount' => 1, // replace later
            'featuredMarket' => [],    // market composable still handles this
        ]);
    }
}