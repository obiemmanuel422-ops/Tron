<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Card;
use Illuminate\Support\Facades\Auth;

class CardController extends Controller
{
    /**
     * List all cards for the authenticated user
     */
    public function index(Request $request)
    {
        $cards = $request->user()->cards()
            ->with('bankAccount:id,account_name,balance')
            ->latest()
            ->get()
            ->map(fn($card) => [
                'id' => $card->id,
                'card_name' => $card->card_name,
                'card_type' => $card->card_type,
                'bank_account' => $card->bankAccount ? [
                    'id' => $card->bankAccount->id,
                    'name' => $card->bankAccount->account_name,
                    'balance' => $card->bankAccount->balance,
                ] : null,
                'daily_limit' => $card->daily_limit,
                'monthly_limit' => $card->monthly_limit,
                'masked_number' => '**** **** **** ' . substr($card->card_number, -4),
                'expiry_date' => $card->expiry_date,
            ]);

        return response()->json(['data' => $cards]);
    }

    /**
     * Create a new card
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'bank_account_id' => 'required|exists:bank_accounts,id',
            'card_name' => 'required|string|max:255',
            'card_type' => 'required|in:debit,credit',
            'daily_limit' => 'required|numeric|min:100',
            'monthly_limit' => 'required|numeric|min:1000',
        ]);

        // Verify the bank account belongs to the authenticated user
        $bankAccount = Auth::user()->bankAccounts()->findOrFail($validated['bank_account_id']);

        // Generate card details for demo; in production, use payment provider API
        $card = Card::create([
            'user_id' => Auth::id(),
            'bank_account_id' => $bankAccount->id,
            'card_number' => fake()->creditCardNumber(),
            'card_name' => $validated['card_name'],
            'card_type' => $validated['card_type'],
            'expiry_date' => fake()->creditCardExpirationDate(),
            'cvv' => fake()->numerify('###'),
            'daily_limit' => $validated['daily_limit'],
            'monthly_limit' => $validated['monthly_limit'],
        ]);

        return response()->json([
            'message' => 'Card created successfully',
            'data' => [
                'id' => $card->id,
                'card_name' => $card->card_name,
                'card_type' => $card->card_type,
                'masked_number' => '**** **** **** ' . substr($card->card_number, -4),
                'expiry_date' => $card->expiry_date,
                'daily_limit' => $card->daily_limit,
                'monthly_limit' => $card->monthly_limit,
            ]
        ], 201);
    }

    /**
     * Show a specific card
     */
    public function show(Card $card)
    {
        $this->authorize('view', $card);

        return response()->json([
            'id' => $card->id,
            'card_name' => $card->card_name,
            'card_type' => $card->card_type,
            'bank_account' => $card->bankAccount ? [
                'id' => $card->bankAccount->id,
                'name' => $card->bankAccount->account_name,
                'balance' => $card->bankAccount->balance,
            ] : null,
            'masked_number' => '**** **** **** ' . substr($card->card_number, -4),
            'expiry_date' => $card->expiry_date,
            'daily_limit' => $card->daily_limit,
            'monthly_limit' => $card->monthly_limit,
        ]);
    }
}