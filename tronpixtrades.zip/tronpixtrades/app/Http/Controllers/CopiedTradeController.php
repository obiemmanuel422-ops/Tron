<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\CopiedTrade;
use App\Models\CopyTradeHistory;
use Illuminate\Support\Facades\DB;

class CopiedTradeController extends Controller
{
    /**
     * List all copied trades for the authenticated user
     */
    public function index(Request $request)
    {
        $copiedTrades = $request->user()->copiedTrades()
            ->with('trader:id,name', 'copyRelationship:id,user_id,trader_id')
            ->latest()
            ->get()
            ->map(fn($trade) => [
                'id' => $trade->id,
                'symbol' => $trade->symbol,
                'side' => $trade->side,
                'size' => $trade->size,
                'leverage' => $trade->leverage,
                'entry_price' => $trade->user_entry,
                'trader' => [
                    'id' => $trade->trader->id,
                    'name' => $trade->trader->name,
                ],
                'relationship_id' => $trade->copy_relationship_id,
                'opened_at' => $trade->created_at->toDateTimeString(),
            ]);

        return response()->json(['data' => $copiedTrades]);
    }

    /**
     * Close a copied trade
     */
    public function close(CopiedTrade $trade, Request $request)
    {
        $this->authorize('update', $trade);

        $validated = $request->validate([
            'exit_price' => 'required|numeric|min:0',
            'pnl' => 'required|numeric',
        ]);

        DB::transaction(function () use ($trade, $validated) {
            // Save closed trade to history
            CopyTradeHistory::create([
                'user_id' => $trade->user_id,
                'trader_id' => $trade->trader_id,
                'copy_relationship_id' => $trade->copy_relationship_id,
                'symbol' => $trade->symbol,
                'side' => $trade->side,
                'leverage' => $trade->leverage,
                'trader_entry' => $trade->trader_entry,
                'user_entry' => $trade->user_entry,
                'exit_price' => $validated['exit_price'],
                'size' => $trade->size,
                'realized_pnl' => $validated['pnl'],
                'closed_at' => now(),
            ]);

            // Remove active trade
            $trade->delete();
        });

        return response()->json([
            'message' => 'Copied trade closed successfully',
            'trade_id' => $trade->id,
        ]);
    }
}