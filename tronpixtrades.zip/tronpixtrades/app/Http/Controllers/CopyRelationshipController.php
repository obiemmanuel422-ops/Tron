<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\CopyRelationship;

class CopyRelationshipController extends Controller
{
    public function getTraders(Request $request)
    {
        $filter = $request->query('filter', 'all');
        $limit = $request->query('limit', 10);

        $query = User::where('account_type', 'broker')
            ->where('id', '!=', auth()->id())
            ->select('id', 'name', 'email', 'created_at');

        // Filter top traders (those with most followers in copy relationships)
        if ($filter === 'top') {
            $query->withCount('copiedRelationships')
                ->orderBy('copied_relationships_count', 'desc');
        } elseif ($filter === 'low-risk') {
            // You would join with a risk rating table in production
            $query->orderBy('created_at', 'desc');
        } else {
            $query->orderBy('created_at', 'desc');
        }

        return $query->limit($limit)->get();
    }

    public function follow(Request $request)
    {
        $validated = $request->validate([
            'trader_id' => 'required|exists:users,id',
            'mode' => 'required|in:fixed,ratio',
            'fixed_amount' => 'nullable|numeric|min:0',
            'ratio' => 'nullable|numeric|min:0|max:1',
            'max_drawdown' => 'nullable|numeric|min:0|max:100',
        ]);

        if ($validated['trader_id'] == auth()->id()) {
            return response()->json(['error' => 'Cannot copy yourself'], 422);
        }

        // Ensure either fixed_amount or ratio is provided
        if ($validated['mode'] === 'fixed' && !isset($validated['fixed_amount'])) {
            return response()->json(['error' => 'Fixed amount required for fixed mode'], 422);
        }

        if ($validated['mode'] === 'ratio' && !isset($validated['ratio'])) {
            return response()->json(['error' => 'Ratio required for ratio mode'], 422);
        }

        $relationship = CopyRelationship::firstOrCreate(
            [
                'user_id' => auth()->id(),
                'trader_id' => $validated['trader_id'],
            ],
            [
                'mode' => $validated['mode'],
                'fixed_amount' => $validated['fixed_amount'] ?? null,
                'ratio' => $validated['ratio'] ?? null,
                'max_drawdown' => $validated['max_drawdown'] ?? null,
                'is_active' => true,
            ]
        );

        return response()->json($relationship, 201);
    }

    public function unfollow(CopyRelationship $relationship, Request $request)
    {
        $this->authorize('delete', $relationship);
        $relationship->delete();
        return response()->json(null, 204);
    }

    public function myFollowing(Request $request)
    {
        return $request->user()->copyRelationships()
            ->with('trader:id,name,email')
            ->get();
    }

    public function myFollowers(Request $request)
    {
        return $request->user()->copiedRelationships()
            ->with('user:id,name,email')
            ->get();
    }
}
