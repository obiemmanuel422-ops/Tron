<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\CopyTradeHistory;

class CopyTradeHistoryController extends Controller
{
    public function index(Request $request)
    {
        return $request->user()->copiedTradeHistories()
            ->with('trader:id,name', 'copyRelationship')
            ->latest('closed_at')
            ->paginate(20);
    }
}