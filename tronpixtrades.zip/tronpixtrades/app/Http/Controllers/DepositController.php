<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Deposit;
use App\Models\Wallet;
use Illuminate\Support\Facades\DB;

class DepositController extends Controller
{
    public function index(Request $request)
    {
        return $request->user()->deposits()
            ->with('wallet:id,currency,balance')
            ->latest()
            ->paginate(20);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'wallet_id' => 'required|exists:wallets,id',
            'amount' => 'required|numeric|min:50',
            'currency' => 'required|string',
            'payment_method' => 'required|in:card,bank_transfer,crypto,paypal',
        ]);

        $wallet = Wallet::findOrFail($validated['wallet_id']);
        
        $this->authorize('view', $wallet);

        DB::transaction(function () use ($validated, $wallet, &$deposit) {
            $deposit = Deposit::create([
                'user_id' => auth()->id(),
                'wallet_id' => $wallet->id,
                'amount' => $validated['amount'],
                'currency' => $validated['currency'],
                'payment_method' => $validated['payment_method'],
                'status' => 'pending',
            ]);

            // In production, integrate with payment gateway here
            // For now, we'll auto-complete deposits
            // $deposit->update(['status' => 'completed', 'completed_at' => now()]);
            // $wallet->increment('balance', $validated['amount']);
            // $wallet->increment('available_balance', $validated['amount']);
        });

        return response()->json($deposit->load('wallet'), 201);
    }

    public function show(Deposit $deposit)
    {
        $this->authorize('view', $deposit);
        return $deposit->load('wallet');
    }

    // Admin endpoints
    public function adminIndex(Request $request)
    {
        if (!auth()->user() || auth()->user()->account_type !== 'admin') {
            return response()->json(['error' => 'Unauthorized'], 403);
        }

        return Deposit::with('user:id,name,email', 'wallet:id,currency,balance')
            ->latest()
            ->paginate(50);
    }
}
