<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Loan;
use Illuminate\Support\Facades\DB;

class LoanController extends Controller
{
    public function index(Request $request)
    {
        return $request->user()->loans()
            ->with('bankAccount:id,account_name', 'payments')
            ->latest()
            ->get();
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'bank_account_id' => 'required|exists:bank_accounts,id',
            'amount' => 'required|numeric|min:1000',
            'currency' => 'required|string|size:3',
            'interest_rate' => 'required|numeric|min:0|max:100',
            'term_months' => 'required|integer|min:3|max:360',
        ]);

        // Verify bank account belongs to user
        $bankAccount = auth()->user()->bankAccounts()
            ->findOrFail($validated['bank_account_id']);

        $loan = auth()->user()->loans()->create($validated);

        return response()->json($loan, 201);
    }

    public function show(Loan $loan)
    {
        $this->authorize('view', $loan);
        return $loan->load('bankAccount', 'payments');
    }

    public function calculatePayment(Loan $loan, Request $request)
    {
        $this->authorize('view', $loan);

        // Simple monthly payment calculation: (P * r * (1+r)^n) / ((1+r)^n - 1)
        $principal = $loan->amount;
        $monthlyRate = $loan->interest_rate / 100 / 12;
        $months = $loan->term_months;

        if ($monthlyRate == 0) {
            $monthlyPayment = $principal / $months;
        } else {
            $monthlyPayment = ($principal * $monthlyRate * pow(1 + $monthlyRate, $months)) / 
                             (pow(1 + $monthlyRate, $months) - 1);
        }

        return response()->json([
            'monthly_payment' => round($monthlyPayment, 2),
            'total_interest' => round(($monthlyPayment * $months) - $principal, 2),
            'total_amount' => round($monthlyPayment * $months, 2),
        ]);
    }
}
