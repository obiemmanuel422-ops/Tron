<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\SecurityStep;

class SecurityVerificationController extends Controller
{
    public function index()
    {
        // Return steps assigned to the authenticated user
        $steps = SecurityStep::where('user_id', auth()->id())
            ->orderBy('id')
            ->get(['id','name','explanation','code','account']);
        return response()->json($steps);
    }

    public function verify(Request $request, SecurityStep $step)
    {
        $request->validate([
            'code' => 'required|string|size:6',
        ]);

        if ($request->code !== $step->code) {
            return response()->json(['message' => 'Invalid security code'], 422);
        }

        // Mark step as completed (optional)
        $step->completed = true;
        $step->save();

        return response()->json(['message' => 'Verified']);
    }
}