<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Transaction;

class TransactionController extends Controller
{
    public function index(Request $request)
    {
        $type = $request->query('type');
        $currency = $request->query('currency');

        $query = $request->user()
            ->transactions()
            ->with('wallet:id,currency,balance');

        if ($type) {
            $query->where('type', $type);
        }

        if ($currency) {
            $query->where('currency', $currency);
        }

        return $query->latest()->paginate(20);
    }

    public function show(Transaction $transaction)
    {
        $this->authorize('view', $transaction);
        return $transaction->load('wallet');
    }
}