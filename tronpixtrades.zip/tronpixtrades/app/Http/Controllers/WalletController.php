<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Wallet;
use App\Models\Transaction;

class WalletController extends Controller
{
    public function index(Request $request)
    {
        return $request->user()->wallets()
            ->with('transactions:id,wallet_id,type,amount,status,created_at')
            ->get();
    }

    public function show(Wallet $wallet)
    {
        $this->authorize('view', $wallet);
        return $wallet->load('transactions:id,wallet_id,type,amount,status,created_at');
    }

    public function getBalance(Wallet $wallet)
    {
        $this->authorize('view', $wallet);
        return response()->json([
            'balance' => $wallet->balance,
            'available_balance' => $wallet->available_balance,
            'locked_balance' => $wallet->locked_balance,
        ]);
    } 
    
    // Set transaction PIN
    public function setPin(Request $request)
    {
        $request->validate([
            'pin' => ['required', 'digits:4'],
        ]);

        $user = Auth::user();
        $user->transaction_pin = Hash::make($request->pin);
        $user->save();

        return response()->json(['message' => 'Transaction PIN set successfully']);
    }

    // Verify PIN
    public function verifyPin(Request $request)
    {
        $request->validate([
            'pin' => ['required', 'digits:4'],
        ]);

        $user = Auth::user();

        if (!$user->transaction_pin || !Hash::check($request->pin, $user->transaction_pin)) {
            return response()->json(['error' => 'Invalid PIN'], 422);
        }

        return response()->json(['message' => 'PIN verified']);
    }

    // Withdraw funds
    public function withdraw(Request $request)
    {
        $request->validate([
            'wallet_id' => ['required'],
            'amount' => ['required', 'numeric', 'min:1'],
            'currency' => ['required'],
            'withdrawal_method' => ['required'],
            'destination' => ['required'],
            'pin' => ['required', 'digits:4'],
        ]);

        $user = Auth::user();

        // Verify PIN
        if (!Hash::check($request->pin, $user->transaction_pin)) {
            return response()->json(['error' => 'Invalid PIN'], 422);
        }

        // Example: create a withdrawal record
        $withdrawal = Withdrawal::create([
            'user_id' => $user->id,
            'wallet_id' => $request->wallet_id,
            'amount' => $request->amount,
            'currency' => $request->currency,
            'method' => $request->withdrawal_method,
            'destination' => $request->destination,
            'status' => 'pending',
        ]);

        return response()->json(['id' => $withdrawal->id]);
    }
}
