<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Withdrawal;
use App\Models\Wallet;
use App\Models\Transaction;
use Illuminate\Support\Facades\DB;

class WithdrawalController extends Controller
{
    /**
     * User withdrawals list
     */
    public function index(Request $request)
    {
        return $request->user()
            ->withdrawals()
            ->with('wallet:id,currency,balance')
            ->latest()
            ->paginate(20);
    }

    /**
     * Create withdrawal request
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'wallet_id' => 'required|exists:wallets,id',
            'amount' => 'required|numeric|min:50',
            'currency' => 'required|string',
            'withdrawal_method' => 'required|in:bank,crypto_wallet,paypal',
            'destination' => 'required|string',
        ]);

        $wallet = Wallet::findOrFail($validated['wallet_id']);
        $this->authorize('view', $wallet);

        if ($wallet->available_balance < $validated['amount']) {
            return back()->withErrors([
                'amount' => 'Insufficient balance',
            ]);
        }

        DB::transaction(function () use ($validated, $wallet) {
            Withdrawal::create([
                'user_id' => auth()->id(),
                'wallet_id' => $wallet->id,
                'amount' => $validated['amount'],
                'currency' => $validated['currency'],
                'withdrawal_method' => $validated['withdrawal_method'],
                'destination' => $validated['destination'],
                'status' => 'pending',
            ]);

            // Lock funds
            $wallet->decrement('available_balance', $validated['amount']);
            $wallet->increment('locked_balance', $validated['amount']);
        });

        return redirect()
            ->back()
            ->with('success', 'Withdrawal request submitted successfully');
    }

    /**
     * View a single withdrawal
     */
    public function show(Withdrawal $withdrawal)
    {
        $this->authorize('view', $withdrawal);
        return $withdrawal->load('wallet');
    }

    /**
     * Admin approve withdrawal
     */
    public function approve(Withdrawal $withdrawal)
    {
        $this->authorize('approve', $withdrawal);

        if ($withdrawal->status !== 'pending') {
            abort(422, 'Withdrawal cannot be approved');
        }

        DB::transaction(function () use ($withdrawal) {

            $withdrawal->update([
                'status' => 'approved',
            ]);

            // ✅ CREATE TRANSACTION RECORD
            Transaction::create([
                'user_id' => $withdrawal->user_id,
                'wallet_id' => $withdrawal->wallet_id,
                'type' => 'withdrawal',
                'amount' => $withdrawal->amount,
                'currency' => $withdrawal->currency,
                'status' => 'completed',
                'reference' => 'WD-' . strtoupper(uniqid()),
                'meta' => [
                    'method' => $withdrawal->withdrawal_method,
                    'destination' => $withdrawal->destination,
                ],
            ]);
        });

        return redirect()
            ->back()
            ->with('success', 'Withdrawal approved successfully');
    }

    /**
     * Admin reject withdrawal
     */
    public function reject(Withdrawal $withdrawal)
    {
        $this->authorize('approve', $withdrawal);

        if ($withdrawal->status !== 'pending') {
            abort(422, 'Withdrawal cannot be rejected');
        }

        DB::transaction(function () use ($withdrawal) {

            $withdrawal->update([
                'status' => 'rejected',
            ]);

            // Unlock funds
            $withdrawal->wallet->increment('available_balance', $withdrawal->amount);
            $withdrawal->wallet->decrement('locked_balance', $withdrawal->amount);
        });

        return redirect()
            ->back()
            ->with('success', 'Withdrawal rejected');
    }

    /**
     * Admin withdrawals list
     */
    public function adminIndex()
    {
        if (!auth()->user() || auth()->user()->account_type !== 'admin') {
            abort(403);
        }

        return Withdrawal::with(
                'user:id,name,email',
                'wallet:id,currency,balance'
            )
            ->latest()
            ->paginate(50);
    }
}