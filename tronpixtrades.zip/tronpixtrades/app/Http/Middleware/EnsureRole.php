<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class EnsureRole
{
    protected string $role;

    public function __construct(string $role = '')
    {
        $this->role = $role;
    }

    public function handle(Request $request, Closure $next, string $role)
    {
        $user = $request->user();

        if (!$user || $user->account_type !== $role) {
            abort(403); // forbidden
        }

        return $next($request);
    }
}