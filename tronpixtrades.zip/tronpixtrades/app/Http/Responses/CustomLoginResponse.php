<?php

namespace App\Http\Responses;

use Laravel\Fortify\Contracts\LoginResponse as LoginResponseContract;
use Illuminate\Support\Facades\Auth;

class CustomLoginResponse implements LoginResponseContract
{
    public function toResponse($request)
    {
        $user = Auth::user();

        // 1️⃣ Check email verification first
        if (!$user->hasVerifiedEmail()) {
            return redirect()->route('verification.notice'); 
            // or your Inertia route: '/verify/email'
        }

        // 2️⃣ Role-based redirection
        return match($user->account_type) {
            'bank' => redirect()->route('banking.dashboard'),
            'broker' => redirect()->route('dashboard'), // broker dashboard
            'admin' => redirect()->route('admin.dashboard'),
            default => redirect()->route('dashboard'),
        };
    }
}