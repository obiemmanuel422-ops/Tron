<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BankAccount extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'account_name',
        'account_number',
        'account_type',
        'currency',
        'balance',
        'available_balance',
        'status',
        'is_primary',
        'metadata',
    ];

    protected $casts = [
        'balance' => 'decimal:8',
        'available_balance' => 'decimal:8',
        'is_primary' => 'boolean',
        'metadata' => 'json',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function cards()
    {
        return $this->hasMany(Card::class);
    }

    public function loans()
    {
        return $this->hasMany(Loan::class);
    }

    public function transactions()
    {
        return $this->hasMany(BankTransaction::class);
    }
}
