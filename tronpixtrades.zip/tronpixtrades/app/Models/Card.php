<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Card extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'bank_account_id',
        'card_number',
        'card_name',
        'card_type',
        'status',
        'expiry_date',
        'cvv',
        'daily_limit',
        'monthly_limit',
        'spent_today',
        'spent_month',
        'metadata',
    ];

    protected $casts = [
        'daily_limit' => 'decimal:8',
        'monthly_limit' => 'decimal:8',
        'spent_today' => 'decimal:8',
        'spent_month' => 'decimal:8',
        'metadata' => 'json',
    ];

    protected $hidden = ['cvv', 'card_number'];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function bankAccount()
    {
        return $this->belongsTo(BankAccount::class);
    }
}
