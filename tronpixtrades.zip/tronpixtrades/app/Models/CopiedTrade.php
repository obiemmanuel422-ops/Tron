<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CopiedTrade extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'trader_id',
        'copy_relationship_id',
        'symbol',
        'side',
        'leverage',
        'trader_entry',
        'user_entry',
        'size',
        'unrealized_pnl'
    ];

    protected $casts = [
        'trader_entry' => 'decimal:8',
        'user_entry' => 'decimal:8',
        'size' => 'decimal:8',
        'unrealized_pnl' => 'decimal:8',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function trader()
    {
        return $this->belongsTo(User::class, 'trader_id');
    }

    public function copyRelationship()
    {
        return $this->belongsTo(CopyRelationship::class);
    }
}