<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CopyRelationship extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'trader_id',
        'mode',
        'fixed_amount',
        'ratio',
        'max_drawdown',
        'is_active',
    ];

    protected $casts = [
        'is_active' => 'boolean',
        'fixed_amount' => 'decimal:8',
        'ratio' => 'decimal:4',
        'max_drawdown' => 'decimal:2',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function trader()
    {
        return $this->belongsTo(User::class, 'trader_id');
    }

    public function copiedTrades()
    {
        return $this->hasMany(CopiedTrade::class);
    }

    public function copiedTradeHistories()
    {
        return $this->hasMany(CopyTradeHistory::class);
    }
}
