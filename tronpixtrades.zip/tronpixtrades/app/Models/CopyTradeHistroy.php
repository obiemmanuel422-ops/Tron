<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CopyTradeHistory extends Model
{
    use HasFactory;

    protected $table = 'copy_trade_histories';

    protected $fillable = [
        'user_id',
        'trader_id',
        'copy_relationship_id',
        'symbol',
        'side',
        'leverage',
        'trader_entry',
        'user_entry',
        'exit_price',
        'size',
        'realized_pnl',
        'closed_at'
    ];

    protected $casts = [
        'trader_entry' => 'decimal:8',
        'user_entry' => 'decimal:8',
        'exit_price' => 'decimal:8',
        'size' => 'decimal:8',
        'realized_pnl' => 'decimal:8',
        'closed_at' => 'datetime',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function trader()
    {
        return $this->belongsTo(User::class, 'trader_id');
    }

    public function copyRelationship()
    {
        return $this->belongsTo(CopyRelationship::class);
    }
}