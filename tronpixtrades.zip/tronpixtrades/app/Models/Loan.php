<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Loan extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'bank_account_id',
        'amount',
        'currency',
        'interest_rate',
        'term_months',
        'status',
        'approved_at',
        'disbursed_at',
        'due_date',
        'metadata',
    ];

    protected $casts = [
        'amount' => 'decimal:8',
        'interest_rate' => 'decimal:4',
        'approved_at' => 'datetime',
        'disbursed_at' => 'datetime',
        'due_date' => 'datetime',
        'metadata' => 'json',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function bankAccount()
    {
        return $this->belongsTo(BankAccount::class);
    }

    public function payments()
    {
        return $this->hasMany(LoanPayment::class);
    }
}
