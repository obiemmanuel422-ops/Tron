<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LoanPayment extends Model
{
    use HasFactory;

    protected $fillable = [
        'loan_id',
        'amount',
        'interest_paid',
        'principal_paid',
        'payment_date',
        'status',
        'transaction_id',
    ];

    protected $casts = [
        'amount' => 'decimal:8',
        'interest_paid' => 'decimal:8',
        'principal_paid' => 'decimal:8',
        'payment_date' => 'datetime',
    ];

    public function loan()
    {
        return $this->belongsTo(Loan::class);
    }
}
