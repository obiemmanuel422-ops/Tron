<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Fortify\TwoFactorAuthenticatable;

class User extends Authenticatable
{
    use HasFactory, Notifiable, TwoFactorAuthenticatable;

    /**
     * Mass assignable attributes.
     */
    protected $fillable = [
        'name',
        'email',
        'password',
        'account_type', // <- added
    ];

    /**
     * Hidden attributes for serialization.
     */
    protected $hidden = [
        'password',
        'two_factor_secret',
        'two_factor_recovery_codes',
        'remember_token',
    ];

    /**
     * Attribute casting.
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
        'password' => 'hashed',
        'two_factor_confirmed_at' => 'datetime',
    ];

    /**
     * Relationships
     */
    public function wallets()
    {
        return $this->hasMany(Wallet::class);
    }

    public function bankAccounts()
    {
        return $this->hasMany(BankAccount::class);
    }

    public function transactions()
    {
        return $this->hasMany(Transaction::class);
    }
      
      public function brokerAccounts()
{
    return $this->hasMany(BrokerAccount::class);
}
    
    public function deposits()
    {
        return $this->hasMany(Deposit::class);
    }

    public function withdrawals()
    {
        return $this->hasMany(Withdrawal::class);
    }

    public function copiedTrades()
    {
        return $this->hasMany(CopiedTrade::class);
    }

    public function copiedTradeHistories()
    {
        return $this->hasMany(CopyTradeHistory::class);
    }

    public function copyRelationships()
    {
        return $this->hasMany(CopyRelationship::class);
    }

    public function copiedRelationships()
    {
        return $this->hasMany(CopyRelationship::class, 'trader_id');
    }

    /**
     * Check if user is admin
     */
    public function isAdmin(): bool
    {
        return $this->account_type === 'admin';
    }

    /**
     * Check if user is bank account holder
     */
    public function isBank(): bool
    {
        return $this->account_type === 'bank';
    }

    /**
     * Check if user is broker
     */
    public function isBroker(): bool
    {
        return $this->account_type === 'broker';
    }
}