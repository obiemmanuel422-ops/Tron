<?php

namespace App\Policies;

use App\Models\User;
use App\Models\CopiedTrade;

class CopiedTradePolicy
{
    public function view(User $user, CopiedTrade $trade): bool
    {
        return $user->id === $trade->user_id;
    }

    public function update(User $user, CopiedTrade $trade): bool
    {
        return $user->id === $trade->user_id;
    }

    public function delete(User $user, CopiedTrade $trade): bool
    {
        return $user->id === $trade->user_id;
    }
}
