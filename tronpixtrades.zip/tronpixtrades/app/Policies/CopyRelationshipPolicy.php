<?php

namespace App\Policies;

use App\Models\User;
use App\Models\CopyRelationship;

class CopyRelationshipPolicy
{
    public function view(User $user, CopyRelationship $relationship): bool
    {
        return $user->id === $relationship->user_id;
    }

    public function delete(User $user, CopyRelationship $relationship): bool
    {
        return $user->id === $relationship->user_id;
    }
}
