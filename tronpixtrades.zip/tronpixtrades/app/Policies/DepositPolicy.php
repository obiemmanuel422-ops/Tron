<?php

namespace App\Policies;

use App\Models\User;
use App\Models\Deposit;

class DepositPolicy
{
    public function view(User $user, Deposit $deposit): bool
    {
        return $user->id === $deposit->user_id;
    }

    public function update(User $user, Deposit $deposit): bool
    {
        return $user->id === $deposit->user_id;
    }

    public function delete(User $user, Deposit $deposit): bool
    {
        return $user->id === $deposit->user_id && $deposit->status === 'pending';
    }
}
