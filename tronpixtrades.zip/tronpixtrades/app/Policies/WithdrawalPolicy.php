<?php

namespace App\Policies;

use App\Models\User;
use App\Models\Withdrawal;

class WithdrawalPolicy
{
    public function view(User $user, Withdrawal $withdrawal): bool
    {
        return $user->id === $withdrawal->user_id;
    }

    public function approve(User $user, Withdrawal $withdrawal): bool
    {
        // Only admins can approve withdrawals
        return $user->isAdmin();
    }

    public function cancel(User $user, Withdrawal $withdrawal): bool
    {
        return $user->id === $withdrawal->user_id && $withdrawal->status === 'pending';
    }
}
