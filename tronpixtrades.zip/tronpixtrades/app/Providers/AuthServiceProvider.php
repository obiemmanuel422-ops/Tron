<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Gate;
use App\Models\Wallet;
use App\Models\BankAccount;
use App\Models\Card;
use App\Models\Deposit;
use App\Models\Withdrawal;
use App\Models\CopiedTrade;
use App\Models\CopyRelationship;
use App\Models\Transaction;
use App\Policies\WalletPolicy;
use App\Policies\BankAccountPolicy;
use App\Policies\CardPolicy;
use App\Policies\DepositPolicy;
use App\Policies\WithdrawalPolicy;
use App\Policies\CopiedTradePolicy;
use App\Policies\CopyRelationshipPolicy;
use App\Policies\TransactionPolicy;

class AuthServiceProvider extends ServiceProvider
{
    /**
     * The model to policy mappings for the application.
     *
     * @var array<class-string, class-string>
     */
    protected $policies = [
        Wallet::class => WalletPolicy::class,
        BankAccount::class => BankAccountPolicy::class,
        Card::class => CardPolicy::class,
        Deposit::class => DepositPolicy::class,
        Withdrawal::class => WithdrawalPolicy::class,
        CopiedTrade::class => CopiedTradePolicy::class,
        CopyRelationship::class => CopyRelationshipPolicy::class,
        Transaction::class => TransactionPolicy::class,
    ];

    /**
     * Register any authentication / authorization services.
     */
    public function boot(): void
    {
        $this->registerPolicies();

        // Define admin gate
        Gate::define('admin', function ($user) {
            return $user->isAdmin();
        });

        // Define bank user gate
        Gate::define('bank', function ($user) {
            return $user->isBank();
        });

        // Define broker user gate
        Gate::define('broker', function ($user) {
            return $user->isBroker();
        });
    }
}
