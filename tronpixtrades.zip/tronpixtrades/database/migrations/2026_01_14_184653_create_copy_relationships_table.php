<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('copy_relationships', function (Blueprint $table) {
    $table->id();

    $table->foreignId('user_id')->constrained()->cascadeOnDelete();
    $table->foreignId('trader_id')->constrained('users')->cascadeOnDelete();

    $table->enum('mode', ['fixed', 'ratio']);
    $table->decimal('fixed_amount', 18, 8)->nullable();
    $table->decimal('ratio', 8, 4)->nullable();

    $table->decimal('max_drawdown', 5, 2)->nullable();
    $table->boolean('is_active')->default(true);

    $table->timestamps();

    $table->unique(['user_id', 'trader_id']);
});
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('copy_relationships');
    }
};
