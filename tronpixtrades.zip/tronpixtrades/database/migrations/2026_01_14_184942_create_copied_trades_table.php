<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('copied_trades', function (Blueprint $table) {
    $table->id();

    $table->foreignId('user_id')->constrained()->cascadeOnDelete();
    $table->foreignId('trader_id')->constrained('users')->cascadeOnDelete();
    $table->foreignId('copy_relationship_id')->constrained()->cascadeOnDelete();

    $table->string('symbol');
    $table->enum('side', ['LONG', 'SHORT']);
    $table->unsignedInteger('leverage');

    $table->decimal('trader_entry', 18, 8);
    $table->decimal('user_entry', 18, 8);

    $table->decimal('size', 18, 8);
    $table->decimal('unrealized_pnl', 18, 8)->default(0);

    $table->timestamps();

    $table->index(['user_id', 'symbol']);
});
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('copied_trades');
    }
};
