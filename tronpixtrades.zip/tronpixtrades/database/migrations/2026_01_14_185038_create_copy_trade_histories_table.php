<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('copy_trade_histories', function (Blueprint $table) {
    $table->id();

    $table->foreignId('user_id')->constrained()->cascadeOnDelete();
    $table->foreignId('trader_id')->constrained('users')->cascadeOnDelete();
    $table->foreignId('copy_relationship_id')->constrained()->cascadeOnDelete();

    $table->string('symbol');
    $table->enum('side', ['LONG', 'SHORT']);
    $table->unsignedInteger('leverage');

    $table->decimal('trader_entry', 18, 8);
    $table->decimal('user_entry', 18, 8);
    $table->decimal('exit_price', 18, 8);

    $table->decimal('size', 18, 8);
    $table->decimal('realized_pnl', 18, 8);

    $table->timestamp('closed_at');

    $table->timestamps();
});
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('copy_trade_histories');
    }
};
