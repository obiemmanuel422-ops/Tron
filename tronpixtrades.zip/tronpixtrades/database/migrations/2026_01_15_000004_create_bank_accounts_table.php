<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('bank_accounts', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('account_name');
            $table->string('account_number')->nullable();
            $table->string('account_type')->default('checking'); // 'checking', 'savings', 'investment'
            $table->string('currency')->default('USD');
            $table->decimal('balance', 18, 8)->default(0);
            $table->decimal('available_balance', 18, 8)->default(0);
            $table->string('status')->default('active'); // 'active', 'frozen', 'closed'
            $table->boolean('is_primary')->default(false);
            $table->json('metadata')->nullable();
            $table->timestamps();

            $table->index(['user_id', 'status']);
            $table->index('is_primary');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('bank_accounts');
    }
};
