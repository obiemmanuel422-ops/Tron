<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('cards', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->foreignId('bank_account_id')->constrained()->cascadeOnDelete();
            $table->string('card_number')->encrypted();
            $table->string('card_name');
            $table->string('card_type')->default('debit'); // 'debit', 'credit'
            $table->string('status')->default('active'); // 'active', 'inactive', 'blocked'
            $table->string('expiry_date'); // MM/YY
            $table->string('cvv')->encrypted();
            $table->decimal('daily_limit', 18, 8)->default(5000);
            $table->decimal('monthly_limit', 18, 8)->default(50000);
            $table->decimal('spent_today', 18, 8)->default(0);
            $table->decimal('spent_month', 18, 8)->default(0);
            $table->json('metadata')->nullable();
            $table->timestamps();

            $table->index(['user_id', 'status']);
            $table->index('bank_account_id');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('cards');
    }
};
