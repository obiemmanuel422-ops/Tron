<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('bank_transactions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('bank_account_id')->constrained()->cascadeOnDelete();
            $table->string('type'); // 'deposit', 'withdrawal', 'transfer', 'loan_disburse', 'payment', 'interest'
            $table->decimal('amount', 18, 8);
            $table->decimal('balance_after', 18, 8);
            $table->text('description')->nullable();
            $table->string('status')->default('completed'); // 'pending', 'completed', 'failed'
            $table->string('reference_id')->nullable()->unique();
            $table->json('metadata')->nullable();
            $table->timestamps();

            $table->index(['bank_account_id', 'type']);
            $table->index(['bank_account_id', 'created_at']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('bank_transactions');
    }
};
