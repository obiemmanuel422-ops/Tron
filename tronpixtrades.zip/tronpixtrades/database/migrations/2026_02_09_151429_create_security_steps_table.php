<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('security_steps', function (Blueprint $table) {
            $table->id();
            $table->string('name'); // Step name, e.g. "Withdrawal Verification"
            $table->text('explanation'); // Step description
            $table->string('code'); // 6-digit security code
            $table->string('account'); // Affected account/area
            $table->enum('type', ['bank', 'broker'])->default('bank'); // For type switch
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('security_steps');
    }
};