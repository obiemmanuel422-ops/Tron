<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use App\Models\Wallet;

class MockBankBrokerSeeder extends Seeder
{
    public function run(): void
    {
        // Admin
        $admin = User::factory()->create([
            'name' => 'Admin User',
            'email' => 'admin@example.com',
            'account_type' => 'admin',
            'password' => bcrypt('password'),
        ]);

        // Bank user
        $bank = User::factory()->create([
            'name' => 'Bank User',
            'email' => 'bank@example.com',
            'account_type' => 'bank',
            'password' => bcrypt('password'),
        ]);

        $bank->wallets()->create([
            'currency' => 'USD',
            'balance' => 1000,
            'available_balance' => 1000,
            'locked_balance' => 0,
        ]);

        // Broker user
        $broker = User::factory()->create([
            'name' => 'Broker User',
            'email' => 'broker@example.com',
            'account_type' => 'broker',
            'password' => bcrypt('password'),
        ]);

        $broker->wallets()->create([
            'currency' => 'USD',
            'balance' => 500,
            'available_balance' => 500,
            'locked_balance' => 0,
        ]);
    }
}
