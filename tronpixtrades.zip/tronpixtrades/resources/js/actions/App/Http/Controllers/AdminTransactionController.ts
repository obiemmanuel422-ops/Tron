import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\AdminTransactionController::credit
* @see app/Http/Controllers/AdminTransactionController.php:49
* @route '/admin/users/credit'
*/
export const credit = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: credit.url(options),
    method: 'post',
})

credit.definition = {
    methods: ["post"],
    url: '/admin/users/credit',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AdminTransactionController::credit
* @see app/Http/Controllers/AdminTransactionController.php:49
* @route '/admin/users/credit'
*/
credit.url = (options?: RouteQueryOptions) => {
    return credit.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminTransactionController::credit
* @see app/Http/Controllers/AdminTransactionController.php:49
* @route '/admin/users/credit'
*/
credit.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: credit.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AdminTransactionController::credit
* @see app/Http/Controllers/AdminTransactionController.php:49
* @route '/admin/users/credit'
*/
const creditForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: credit.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AdminTransactionController::credit
* @see app/Http/Controllers/AdminTransactionController.php:49
* @route '/admin/users/credit'
*/
creditForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: credit.url(options),
    method: 'post',
})

credit.form = creditForm

/**
* @see \App\Http\Controllers\AdminTransactionController::deduct
* @see app/Http/Controllers/AdminTransactionController.php:95
* @route '/admin/users/deduct'
*/
export const deduct = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: deduct.url(options),
    method: 'post',
})

deduct.definition = {
    methods: ["post"],
    url: '/admin/users/deduct',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AdminTransactionController::deduct
* @see app/Http/Controllers/AdminTransactionController.php:95
* @route '/admin/users/deduct'
*/
deduct.url = (options?: RouteQueryOptions) => {
    return deduct.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminTransactionController::deduct
* @see app/Http/Controllers/AdminTransactionController.php:95
* @route '/admin/users/deduct'
*/
deduct.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: deduct.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AdminTransactionController::deduct
* @see app/Http/Controllers/AdminTransactionController.php:95
* @route '/admin/users/deduct'
*/
const deductForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: deduct.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AdminTransactionController::deduct
* @see app/Http/Controllers/AdminTransactionController.php:95
* @route '/admin/users/deduct'
*/
deductForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: deduct.url(options),
    method: 'post',
})

deduct.form = deductForm

const AdminTransactionController = { credit, deduct }

export default AdminTransactionController