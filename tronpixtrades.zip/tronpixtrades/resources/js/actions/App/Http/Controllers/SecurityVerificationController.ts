import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\SecurityVerificationController::index
* @see app/Http/Controllers/SecurityVerificationController.php:10
* @route '/security-steps'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/security-steps',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SecurityVerificationController::index
* @see app/Http/Controllers/SecurityVerificationController.php:10
* @route '/security-steps'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SecurityVerificationController::index
* @see app/Http/Controllers/SecurityVerificationController.php:10
* @route '/security-steps'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SecurityVerificationController::index
* @see app/Http/Controllers/SecurityVerificationController.php:10
* @route '/security-steps'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SecurityVerificationController::index
* @see app/Http/Controllers/SecurityVerificationController.php:10
* @route '/security-steps'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SecurityVerificationController::index
* @see app/Http/Controllers/SecurityVerificationController.php:10
* @route '/security-steps'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SecurityVerificationController::index
* @see app/Http/Controllers/SecurityVerificationController.php:10
* @route '/security-steps'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\SecurityVerificationController::verify
* @see app/Http/Controllers/SecurityVerificationController.php:19
* @route '/security-steps/{step}/verify'
*/
export const verify = (args: { step: string | number | { id: string | number } } | [step: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: verify.url(args, options),
    method: 'post',
})

verify.definition = {
    methods: ["post"],
    url: '/security-steps/{step}/verify',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SecurityVerificationController::verify
* @see app/Http/Controllers/SecurityVerificationController.php:19
* @route '/security-steps/{step}/verify'
*/
verify.url = (args: { step: string | number | { id: string | number } } | [step: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { step: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { step: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            step: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        step: typeof args.step === 'object'
        ? args.step.id
        : args.step,
    }

    return verify.definition.url
            .replace('{step}', parsedArgs.step.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SecurityVerificationController::verify
* @see app/Http/Controllers/SecurityVerificationController.php:19
* @route '/security-steps/{step}/verify'
*/
verify.post = (args: { step: string | number | { id: string | number } } | [step: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: verify.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\SecurityVerificationController::verify
* @see app/Http/Controllers/SecurityVerificationController.php:19
* @route '/security-steps/{step}/verify'
*/
const verifyForm = (args: { step: string | number | { id: string | number } } | [step: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: verify.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\SecurityVerificationController::verify
* @see app/Http/Controllers/SecurityVerificationController.php:19
* @route '/security-steps/{step}/verify'
*/
verifyForm.post = (args: { step: string | number | { id: string | number } } | [step: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: verify.url(args, options),
    method: 'post',
})

verify.form = verifyForm

const SecurityVerificationController = { index, verify }

export default SecurityVerificationController