import WalletController from './WalletController'
import SecurityVerificationController from './SecurityVerificationController'
import DepositController from './DepositController'
import WithdrawalController from './WithdrawalController'
import TransactionController from './TransactionController'
import CardController from './CardController'
import LoanController from './LoanController'
import AdminUserController from './AdminUserController'
import AdminTransactionController from './AdminTransactionController'
import Settings from './Settings'

const Controllers = {
    WalletController: Object.assign(WalletController, WalletController),
    SecurityVerificationController: Object.assign(SecurityVerificationController, SecurityVerificationController),
    DepositController: Object.assign(DepositController, DepositController),
    WithdrawalController: Object.assign(WithdrawalController, WithdrawalController),
    TransactionController: Object.assign(TransactionController, TransactionController),
    CardController: Object.assign(CardController, CardController),
    LoanController: Object.assign(LoanController, LoanController),
    AdminUserController: Object.assign(AdminUserController, AdminUserController),
    AdminTransactionController: Object.assign(AdminTransactionController, AdminTransactionController),
    Settings: Object.assign(Settings, Settings),
}

export default Controllers