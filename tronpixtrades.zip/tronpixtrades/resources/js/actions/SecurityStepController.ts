import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../wayfinder'
/**
* @see \SecurityStepController::index
* @see [unknown]:0
* @route '/admin/security-steps'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/security-steps',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \SecurityStepController::index
* @see [unknown]:0
* @route '/admin/security-steps'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \SecurityStepController::index
* @see [unknown]:0
* @route '/admin/security-steps'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \SecurityStepController::index
* @see [unknown]:0
* @route '/admin/security-steps'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \SecurityStepController::index
* @see [unknown]:0
* @route '/admin/security-steps'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \SecurityStepController::index
* @see [unknown]:0
* @route '/admin/security-steps'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \SecurityStepController::index
* @see [unknown]:0
* @route '/admin/security-steps'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \SecurityStepController::store
* @see [unknown]:0
* @route '/admin/security-steps'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/security-steps',
} satisfies RouteDefinition<["post"]>

/**
* @see \SecurityStepController::store
* @see [unknown]:0
* @route '/admin/security-steps'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \SecurityStepController::store
* @see [unknown]:0
* @route '/admin/security-steps'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \SecurityStepController::store
* @see [unknown]:0
* @route '/admin/security-steps'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \SecurityStepController::store
* @see [unknown]:0
* @route '/admin/security-steps'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \SecurityStepController::update
* @see [unknown]:0
* @route '/admin/security-steps/{securityStep}'
*/
export const update = (args: { securityStep: string | number } | [securityStep: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/security-steps/{securityStep}',
} satisfies RouteDefinition<["put"]>

/**
* @see \SecurityStepController::update
* @see [unknown]:0
* @route '/admin/security-steps/{securityStep}'
*/
update.url = (args: { securityStep: string | number } | [securityStep: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { securityStep: args }
    }

    if (Array.isArray(args)) {
        args = {
            securityStep: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        securityStep: args.securityStep,
    }

    return update.definition.url
            .replace('{securityStep}', parsedArgs.securityStep.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \SecurityStepController::update
* @see [unknown]:0
* @route '/admin/security-steps/{securityStep}'
*/
update.put = (args: { securityStep: string | number } | [securityStep: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \SecurityStepController::update
* @see [unknown]:0
* @route '/admin/security-steps/{securityStep}'
*/
const updateForm = (args: { securityStep: string | number } | [securityStep: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \SecurityStepController::update
* @see [unknown]:0
* @route '/admin/security-steps/{securityStep}'
*/
updateForm.put = (args: { securityStep: string | number } | [securityStep: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \SecurityStepController::destroy
* @see [unknown]:0
* @route '/admin/security-steps/{securityStep}'
*/
export const destroy = (args: { securityStep: string | number } | [securityStep: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/security-steps/{securityStep}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \SecurityStepController::destroy
* @see [unknown]:0
* @route '/admin/security-steps/{securityStep}'
*/
destroy.url = (args: { securityStep: string | number } | [securityStep: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { securityStep: args }
    }

    if (Array.isArray(args)) {
        args = {
            securityStep: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        securityStep: args.securityStep,
    }

    return destroy.definition.url
            .replace('{securityStep}', parsedArgs.securityStep.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \SecurityStepController::destroy
* @see [unknown]:0
* @route '/admin/security-steps/{securityStep}'
*/
destroy.delete = (args: { securityStep: string | number } | [securityStep: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \SecurityStepController::destroy
* @see [unknown]:0
* @route '/admin/security-steps/{securityStep}'
*/
const destroyForm = (args: { securityStep: string | number } | [securityStep: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \SecurityStepController::destroy
* @see [unknown]:0
* @route '/admin/security-steps/{securityStep}'
*/
destroyForm.delete = (args: { securityStep: string | number } | [securityStep: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const SecurityStepController = { index, store, update, destroy }

export default SecurityStepController