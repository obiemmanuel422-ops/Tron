<script setup lang="ts">
import { Link } from "@inertiajs/vue3";
import { Home, Wallet, TrendingUp, Coins, Target, Settings } from "lucide-vue-next";

/* Footer items */
const footerLinks = [
  { name: 'Home', icon: Home, route: '/dashboard' },
  { name: 'Wallet', icon: Wallet, route: '/wallet' },
  { name: 'Trade', icon: TrendingUp, route: '/trade' },
  { name: 'Markets', icon: Coins, route: '/markets' },
  { name: 'Copy', icon: Target, route: '/copy-trading' },
  { name: 'Settings', icon: Settings, route: '/settings' }, // Added
];
</script>

<template>
  <footer class="bg-black border-t border-green-500/20 text-white fixed bottom-0 w-full z-50">
    <div class="max-w-md mx-auto flex justify-between py-2 px-4 text-[10px]">
      <Link
        v-for="(item, i) in footerLinks"
        :key="i"
        :href="item.route"
        class="flex flex-col items-center justify-center gap-0.5 text-white hover:text-green-400"
      >
        <component :is="item.icon" class="w-4 h-4" /> <!-- ✅ FIXED -->
        <span>{{ item.name }}</span>
      </Link>
    </div>
  </footer>
</template>

<style scoped>
footer {
  backdrop-filter: blur(6px);
}
</style>