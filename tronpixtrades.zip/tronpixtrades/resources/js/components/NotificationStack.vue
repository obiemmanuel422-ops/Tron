<template>
  <div class="fixed top-4 right-4 z-[1000] space-y-2 max-w-xs">
    <transition-group name="notification" tag="div" class="space-y-2">
      <div
        v-for="notif in notifications"
        :key="notif.id"
        class="p-4 rounded-lg shadow-lg flex items-start gap-3 animate-slideIn"
        :class="{
          'bg-green-500/20 border border-green-500/50 text-green-400': notif.type === 'success',
          'bg-red-500/20 border border-red-500/50 text-red-400': notif.type === 'error',
          'bg-yellow-500/20 border border-yellow-500/50 text-yellow-400': notif.type === 'warning',
          'bg-blue-500/20 border border-blue-500/50 text-blue-400': notif.type === 'info',
        }"
      >
        <div class="flex-1">
          <p class="font-semibold text-sm">{{ notif.title }}</p>
          <p class="text-xs opacity-90 mt-1">{{ notif.message }}</p>
        </div>
        <button
          @click="removeNotification(notif.id)"
          class="text-white/60 hover:text-white transition"
        >
          ✕
        </button>
      </div>
    </transition-group>
  </div>
</template>

<script setup lang="ts">
import { useNotifications } from '@/composables/useNotifications'

const { notifications, removeNotification } = useNotifications()
</script>

<style scoped>
@keyframes slideIn {
  from {
    transform: translateX(400px);
    opacity: 0;
  }
  to {
    transform: translateX(0);
    opacity: 1;
  }
}

.animate-slideIn {
  animation: slideIn 0.3s ease-out;
}

.notification-enter-active,
.notification-leave-active {
  transition: all 0.3s ease;
}

.notification-enter-from {
  transform: translateX(400px);
  opacity: 0;
}

.notification-leave-to {
  transform: translateX(400px);
  opacity: 0;
}
</style>
