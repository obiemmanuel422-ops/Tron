<script setup lang="ts">
import { onMounted, ref } from "vue"

const props = defineProps<{
  symbol: string
}>()

const chartId = ref("tv_chart_" + Math.random().toString(36).substring(2))

onMounted(() => {
  const script = document.createElement("script")
  script.src = "https://s3.tradingview.com/tv.js"
  script.async = true

  script.onload = () => {
    // @ts-ignore
    new TradingView.widget({
      container_id: chartId.value,
      width: "100%",
      height: "100%",
      symbol: props.symbol,
      interval: "60",
      timezone: "Etc/UTC",
      theme: "dark",
      style: "1",
      locale: "en",
      toolbar_bg: "#0b0b0b",
      enable_publishing: false,
      hide_top_toolbar: true,
      hide_side_toolbar: true,
      allow_symbol_change: false,
      save_image: false,
      details: false,
      backgroundColor: "#0b0b0b",
    })
  }

  document.body.appendChild(script)
})
</script>

<template>
  <div
    :id="chartId"
    class="w-full h-full rounded-2xl overflow-hidden"
  />
</template>