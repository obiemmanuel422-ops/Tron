import { ref } from 'vue'
import { adminService } from '@/services/adminService'

export function useAdminWithdrawals() {
  const withdrawals = ref<any[]>([])
  const loading = ref(false)
  const actionLoading = ref(false)
  const error = ref<string | null>(null)
  const currentPage = ref(1)
  const totalPages = ref(1)

  const fetchWithdrawals = async (page = 1) => {
    try {
      loading.value = true
      error.value = null
      const data = await adminService.getWithdrawals(page)
      withdrawals.value = data.data || []
      currentPage.value = data.current_page || 1
      totalPages.value = data.last_page || 1
    } catch (err: any) {
      error.value = err.message || 'Failed to fetch withdrawals'
      console.error('Error fetching admin withdrawals:', err)
      withdrawals.value = []
    } finally {
      loading.value = false
    }
  }

  const approveWithdrawal = async (withdrawalId: number) => {
    try {
      actionLoading.value = true
      error.value = null
      const updated = await adminService.approveWithdrawal(withdrawalId)
      // Update the local list
      const index = withdrawals.value.findIndex(w => w.id === withdrawalId)
      if (index >= 0) {
        withdrawals.value[index] = updated
      }
      return updated
    } catch (err: any) {
      error.value = err.message || 'Failed to approve withdrawal'
      throw err
    } finally {
      actionLoading.value = false
    }
  }

  const rejectWithdrawal = async (withdrawalId: number) => {
    try {
      actionLoading.value = true
      error.value = null
      const updated = await adminService.rejectWithdrawal(withdrawalId)
      // Update the local list
      const index = withdrawals.value.findIndex(w => w.id === withdrawalId)
      if (index >= 0) {
        withdrawals.value[index] = updated
      }
      return updated
    } catch (err: any) {
      error.value = err.message || 'Failed to reject withdrawal'
      throw err
    } finally {
      actionLoading.value = false
    }
  }

  return {
    withdrawals,
    loading,
    actionLoading,
    error,
    currentPage,
    totalPages,
    fetchWithdrawals,
    approveWithdrawal,
    rejectWithdrawal,
  }
}
