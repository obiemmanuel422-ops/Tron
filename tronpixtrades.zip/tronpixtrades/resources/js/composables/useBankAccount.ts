import { ref } from 'vue'
import { bankAccountService } from '@/services/bankAccountService'

export function useBankAccount() {
  const accounts = ref<any[]>([])
  const loading = ref(false)
  const error = ref<string | null>(null)

  const fetchAccounts = async () => {
    try {
      loading.value = true
      error.value = null
      accounts.value = await bankAccountService.getBankAccounts()
    } catch (err) {
      error.value = err instanceof Error ? err.message : 'Failed to fetch accounts'
    } finally {
      loading.value = false
    }
  }

  const createAccount = async (data: any) => {
    try {
      loading.value = true
      error.value = null
      const newAccount = await bankAccountService.createBankAccount(data)
      accounts.value.push(newAccount)
      return newAccount
    } catch (err) {
      error.value = err instanceof Error ? err.message : 'Failed to create account'
      throw err
    } finally {
      loading.value = false
    }
  }

  return {
    accounts,
    loading,
    error,
    fetchAccounts,
    createAccount,
  }
}
