import { ref } from 'vue'
import { useFundingRate } from './useFundingRate'
import { useLiquidationEngine } from './useLiquidationEngine'
import { useInsuranceFund } from './useInsuranceFund'

const markPrice = ref(0)

export function useFuturesEngine() {
  const funding = useFundingRate()
  const liquidation = useLiquidationEngine()
  const insurance = useInsuranceFund()

  const onPriceUpdate = (
    futuresPrice: number,
    spotPrice: number,
    positions: any[]
  ) => {
    markPrice.value = Number(futuresPrice) || 0

    funding.calculateFunding(futuresPrice, spotPrice)

    positions.forEach(pos => {
      if (liquidation.checkLiquidation(pos, futuresPrice)) {
        liquidation.liquidate(pos, insurance)
      }
    })
  }

  return {
    markPrice,
    funding,
    liquidation,
    insurance,
    onPriceUpdate,
  }
}