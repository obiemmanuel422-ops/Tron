import { type RouteFormDefinition } from './../../wayfinder'

const login = (): RouteFormDefinition<'post'> => ({
  action: login.url(),
  method: 'post',
})

login.url = () => '/login'

const loginForm = (): RouteFormDefinition<'post'> => ({
  action: login.url(),
  method: 'post',
})

login.form = loginForm

export default login