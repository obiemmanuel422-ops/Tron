import { type RouteFormDefinition } from './../../wayfinder'

const register = (): RouteFormDefinition<'post'> => ({
  action: register.url(),
  method: 'post',
})

register.url = () => '/register'

const registerForm = (): RouteFormDefinition<'post'> => ({
  action: register.url(),
  method: 'post',
})

register.form = registerForm

export default register