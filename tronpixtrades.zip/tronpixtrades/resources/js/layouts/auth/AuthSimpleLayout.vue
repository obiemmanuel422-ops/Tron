<script setup lang="ts">
import AppLogo from '@/components/AppLogo.vue';
import { home } from '@/routes';
import { Link } from '@inertiajs/vue3';

defineProps<{
    title?: string;
    description?: string;
}>();
</script>

<template>
  <div
    class="relative flex min-h-svh flex-col items-center justify-center gap-6
           bg-background p-6 md:p-10 overflow-hidden"
  >
    <!-- Dark mode floating orbs -->
    <div
      class="pointer-events-none absolute inset-0 hidden dark:block"
      aria-hidden="true"
    >
      <!-- Orb 1 -->
      <span
        class="absolute left-[15%] top-[20%] size-24 rounded-full
               bg-white/5 blur-2xl
               animate-orb-float-slow"
      />
      <!-- Orb 2 -->
      <span
        class="absolute right-[10%] top-[35%] size-20 rounded-full
               bg-white/4 blur-2xl
               animate-orb-float"
      />
      <!-- Orb 3 -->
      <span
        class="absolute left-[30%] bottom-[15%] size-28 rounded-full
               bg-white/3 blur-3xl
               animate-orb-float-reverse"
      />
    </div>

    <!-- Content -->
    <div class="relative w-full max-w-sm">
      <div class="flex flex-col gap-8">
        <!-- Logo + Brand -->
        <div class="flex flex-col items-center gap-4">
          <Link :href="home()" class="flex items-center gap-2 font-medium">
            <AppLogo />
            <span class="sr-only">{{ title }}</span>
          </Link>

          <!-- Title + description -->
          <div class="space-y-2 text-center">
            <h1 class="text-xl font-medium">{{ title }}</h1>
            <p class="text-sm text-muted-foreground">
              {{ description }}
            </p>
          </div>
        </div>

        <!-- Slot for form -->
        <slot />
      </div>
    </div>
  </div>
</template>