<script setup lang="ts">
import { useForm, Head } from '@inertiajs/vue3'
import InputError from '@/components/InputError.vue'
import TextLink from '@/components/TextLink.vue'
import { Button } from '@/components/ui/button'
import { Checkbox } from '@/components/ui/checkbox'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Spinner } from '@/components/ui/spinner'
import AuthBase from '@/layouts/AuthLayout.vue'
import login from '@/custom-routes/login'
import { request as forgotPassword } from '@/routes/password'

// Inertia form
const form = useForm({
  email: '',
  password: '',
  remember: false,
})

// Props passed from backend
defineProps<{
  status?: string
  canResetPassword: boolean
  canRegister: boolean
}>()

// Form submit
const submitForm = () => {
  form.post(login.form().action, {
    preserveScroll: true,
    onSuccess: () => {
      // Backend handles redirection based on account_type
    },
  })
}
</script>

<template>
<AuthBase
  title="Log in to your account"
  description="Enter your email and password below to log in"
>
  <Head title="Log in" />

  <!-- Success status -->
  <div v-if="status" class="mb-4 text-center text-sm font-medium text-green-600">
    {{ status }}
  </div>

  <form @submit.prevent="submitForm" class="glass-soft flex flex-col gap-6">
    <div class="grid gap-6">
      <!-- EMAIL -->
      <div class="grid gap-2">
        <Label for="email">Email address</Label>
        <Input
          id="email"
          type="email"
          name="email"
          v-model="form.email"
          required
          autofocus
          autocomplete="email"
          placeholder="email@example.com"
        />
        <InputError :message="form.errors.email" />
      </div>

      <!-- PASSWORD -->
      <div class="grid gap-2">
        <div class="flex items-center justify-between">
          <Label for="password">Password</Label>
          <TextLink
            v-if="canResetPassword"
            :href="forgotPassword()"
            class="text-sm"
          >
            Forgot password?
          </TextLink>
        </div>
        <Input
          id="password"
          type="password"
          name="password"
          v-model="form.password"
          required
          autocomplete="current-password"
          placeholder="Password"
        />
        <InputError :message="form.errors.password" />
      </div>

      <!-- REMEMBER ME -->
      <div class="flex items-center space-x-3">
        <Checkbox id="remember" name="remember" v-model="form.remember" />
        <Label for="remember">Remember me</Label>
      </div>

      <!-- SUBMIT -->
      <Button
        type="submit"
        class="mt-4 w-full"
        :disabled="form.processing"
      >
        <Spinner v-if="form.processing" />
        <span v-else>Log in</span>
      </Button>
    </div>

    <!-- REGISTER LINK -->
    <div class="text-center text-sm text-muted-foreground mt-2" v-if="canRegister">
      Don't have an account?
      <TextLink :href="login.form().action">Sign up</TextLink>
    </div>
  </form>
</AuthBase>
</template>