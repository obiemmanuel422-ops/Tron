<script setup lang="ts">
import { Button } from '@/components/ui/button'
import { router } from '@inertiajs/vue3'
import { CheckCircle2 } from 'lucide-vue-next'

const resendVerification = () => {
  router.post('/email/verification-notification')
}
</script>

<template>
  <div class="min-h-screen flex items-center justify-center bg-black px-4">
    <div class="max-w-md w-full glass-soft rounded-2xl p-8 text-center space-y-6">

      <!-- Icon -->
      <div class="flex justify-center">
        <CheckCircle2 class="w-16 h-16 text-green-400 animate-[scaleIn_0.5s_ease-out]" />
      </div>

      <!-- Title -->
      <h2 class="text-2xl font-bold text-white">Verify Your Email</h2>

      <!-- Description -->
      <p class="text-sm text-white/60">
        A verification link has been sent to your email address. <br>
        Please check your inbox and click the link to verify your account.
      </p>

      <!-- Resend Email Button -->
      <Button
        class="w-full"
        @click="resendVerification"
      >
        Resend Email
      </Button>

      <!-- Back to Login -->
      <Button
        variant="outline"
        class="w-full"
        @click="router.visit('/login')"
      >
        Back to Login
      </Button>

      <p class="text-[10px] text-white/40 mt-4">
        Didn’t receive the email? Check your spam folder.
      </p>
    </div>
  </div>
</template>

<style scoped>
@keyframes scaleIn {
  0% { transform: scale(0); opacity: 0; }
  100% { transform: scale(1); opacity: 1; }
}
.animate-[scaleIn_0.5s_ease-out] {
  animation: scaleIn 0.5s ease-out forwards;
}
</style>