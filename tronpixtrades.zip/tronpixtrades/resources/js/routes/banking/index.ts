import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see routes/web.php:181
* @route '/bank/dashboard'
*/
export const dashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

dashboard.definition = {
    methods: ["get","head"],
    url: '/bank/dashboard',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:181
* @route '/bank/dashboard'
*/
dashboard.url = (options?: RouteQueryOptions) => {
    return dashboard.definition.url + queryParams(options)
}

/**
* @see routes/web.php:181
* @route '/bank/dashboard'
*/
dashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

/**
* @see routes/web.php:181
* @route '/bank/dashboard'
*/
dashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dashboard.url(options),
    method: 'head',
})

/**
* @see routes/web.php:181
* @route '/bank/dashboard'
*/
const dashboardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url(options),
    method: 'get',
})

/**
* @see routes/web.php:181
* @route '/bank/dashboard'
*/
dashboardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url(options),
    method: 'get',
})

/**
* @see routes/web.php:181
* @route '/bank/dashboard'
*/
dashboardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

dashboard.form = dashboardForm

/**
* @see routes/web.php:182
* @route '/bank/wallet'
*/
export const wallet = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: wallet.url(options),
    method: 'get',
})

wallet.definition = {
    methods: ["get","head"],
    url: '/bank/wallet',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:182
* @route '/bank/wallet'
*/
wallet.url = (options?: RouteQueryOptions) => {
    return wallet.definition.url + queryParams(options)
}

/**
* @see routes/web.php:182
* @route '/bank/wallet'
*/
wallet.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: wallet.url(options),
    method: 'get',
})

/**
* @see routes/web.php:182
* @route '/bank/wallet'
*/
wallet.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: wallet.url(options),
    method: 'head',
})

/**
* @see routes/web.php:182
* @route '/bank/wallet'
*/
const walletForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: wallet.url(options),
    method: 'get',
})

/**
* @see routes/web.php:182
* @route '/bank/wallet'
*/
walletForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: wallet.url(options),
    method: 'get',
})

/**
* @see routes/web.php:182
* @route '/bank/wallet'
*/
walletForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: wallet.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

wallet.form = walletForm

/**
* @see routes/web.php:183
* @route '/bank/deposit'
*/
export const deposit = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: deposit.url(options),
    method: 'get',
})

deposit.definition = {
    methods: ["get","head"],
    url: '/bank/deposit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:183
* @route '/bank/deposit'
*/
deposit.url = (options?: RouteQueryOptions) => {
    return deposit.definition.url + queryParams(options)
}

/**
* @see routes/web.php:183
* @route '/bank/deposit'
*/
deposit.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: deposit.url(options),
    method: 'get',
})

/**
* @see routes/web.php:183
* @route '/bank/deposit'
*/
deposit.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: deposit.url(options),
    method: 'head',
})

/**
* @see routes/web.php:183
* @route '/bank/deposit'
*/
const depositForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: deposit.url(options),
    method: 'get',
})

/**
* @see routes/web.php:183
* @route '/bank/deposit'
*/
depositForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: deposit.url(options),
    method: 'get',
})

/**
* @see routes/web.php:183
* @route '/bank/deposit'
*/
depositForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: deposit.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

deposit.form = depositForm

/**
* @see routes/web.php:184
* @route '/bank/withdraw'
*/
export const withdraw = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: withdraw.url(options),
    method: 'get',
})

withdraw.definition = {
    methods: ["get","head"],
    url: '/bank/withdraw',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:184
* @route '/bank/withdraw'
*/
withdraw.url = (options?: RouteQueryOptions) => {
    return withdraw.definition.url + queryParams(options)
}

/**
* @see routes/web.php:184
* @route '/bank/withdraw'
*/
withdraw.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: withdraw.url(options),
    method: 'get',
})

/**
* @see routes/web.php:184
* @route '/bank/withdraw'
*/
withdraw.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: withdraw.url(options),
    method: 'head',
})

/**
* @see routes/web.php:184
* @route '/bank/withdraw'
*/
const withdrawForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: withdraw.url(options),
    method: 'get',
})

/**
* @see routes/web.php:184
* @route '/bank/withdraw'
*/
withdrawForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: withdraw.url(options),
    method: 'get',
})

/**
* @see routes/web.php:184
* @route '/bank/withdraw'
*/
withdrawForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: withdraw.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

withdraw.form = withdrawForm

const banking = {
    dashboard: Object.assign(dashboard, dashboard),
    wallet: Object.assign(wallet, wallet),
    deposit: Object.assign(deposit, deposit),
    withdraw: Object.assign(withdraw, withdraw),
}

export default banking