import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see routes/web.php:137
* @route '/markets/{symbol}'
*/
export const profile = (args: { symbol: string | number } | [symbol: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: profile.url(args, options),
    method: 'get',
})

profile.definition = {
    methods: ["get","head"],
    url: '/markets/{symbol}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:137
* @route '/markets/{symbol}'
*/
profile.url = (args: { symbol: string | number } | [symbol: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { symbol: args }
    }

    if (Array.isArray(args)) {
        args = {
            symbol: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        symbol: args.symbol,
    }

    return profile.definition.url
            .replace('{symbol}', parsedArgs.symbol.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see routes/web.php:137
* @route '/markets/{symbol}'
*/
profile.get = (args: { symbol: string | number } | [symbol: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: profile.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:137
* @route '/markets/{symbol}'
*/
profile.head = (args: { symbol: string | number } | [symbol: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: profile.url(args, options),
    method: 'head',
})

/**
* @see routes/web.php:137
* @route '/markets/{symbol}'
*/
const profileForm = (args: { symbol: string | number } | [symbol: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: profile.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:137
* @route '/markets/{symbol}'
*/
profileForm.get = (args: { symbol: string | number } | [symbol: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: profile.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:137
* @route '/markets/{symbol}'
*/
profileForm.head = (args: { symbol: string | number } | [symbol: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: profile.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

profile.form = profileForm

const market = {
    profile: Object.assign(profile, profile),
}

export default market