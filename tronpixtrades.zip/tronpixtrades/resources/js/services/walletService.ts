import { api } from './http'

export const walletService = {
  getWallets() {
    return api.get('/wallets')
  },

  getWallet(walletId: number) {
    return api.get(`/wallets/${walletId}`)
  },

  getBalance(walletId: number) {
    return api.get(`/wallets/${walletId}/balance`)
  },
}
