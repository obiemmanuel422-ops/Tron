import { reactive } from 'vue'

export const market = reactive({
  symbol: 'BNBUSDT',

  lastPrice: 0,
  bids: [] as [string, string][],
  asks: [] as [string, string][],
  trades: [] as any[],

  setPrice(price: number) {
    this.lastPrice = price
  },

  setBook(bids: any[], asks: any[]) {
    this.bids = bids
    this.asks = asks
  },

  setTrades(trades: any[]) {
    this.trades = trades
  }
})