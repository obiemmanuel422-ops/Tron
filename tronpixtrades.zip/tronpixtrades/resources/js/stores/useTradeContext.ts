import { reactive } from 'vue'

export const trade = reactive({
  side: 'BUY' as 'BUY' | 'SELL',
  type: 'LIMIT' as 'LIMIT' | 'MARKET',

  price: null as number | null,
  amount: null as number | null,

  balance: 1000,
  feeRate: 0.001,

  setPrice(price: number) {
    this.price = price
  },

  setAmountByPercent(pct: number) {
    this.amount = (this.balance * pct) / 100
  }
})