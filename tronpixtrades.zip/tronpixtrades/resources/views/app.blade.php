<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" class="dark">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        {{-- Inline script to force dark mode immediately and clear any light-mode overrides --}}
        <script>
            (function() {
                // Force the dark class on the HTML element immediately to block light-mode rendering
                document.documentElement.classList.add('dark');
                
                // If your starter kit uses localStorage to remember a preference, force it to 'dark'
                // This prevents Vue components from switching it back to light on load.
                localStorage.setItem('appearance', 'dark');
                localStorage.setItem('theme', 'dark');
                localStorage.setItem('color-theme', 'dark');
            })();
        </script>

        {{-- Set the background color to dark by default to prevent "White Flash" during load --}}
        <style>
            html {
                /* The dark color from your oklch configuration */
                background-color: oklch(0.145 0 0);
            }
            
            /* Optional: define light mode only if explicitly called, otherwise ignore it */
            html.light {
                background-color: oklch(1 0 0);
            }
        </style>

        <title inertia>{{ config('app.name', 'Laravel') }}</title>

        <link rel="icon" href="/favicon.ico" sizes="any">
        <link rel="icon" href="/favicon.svg" type="image/svg+xml">
        <link rel="apple-touch-icon" href="/apple-touch-icon.png">

        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="fonts.bunny.net" rel="stylesheet" />

        @vite(['resources/js/app.ts', "resources/js/pages/{$page['component']}.vue"])
        @inertiaHead
    </head>
    <body class="font-sans antialiased bg-white dark:bg-black">
        @inertia 

@if(app()->environment('local'))
    <!-- Eruda Mobile Console -->
    <script src="https://cdn.jsdelivr.net/npm/eruda"></script>
    <script>
        eruda.init();
    </script>
@endif
    </body>
</html>
