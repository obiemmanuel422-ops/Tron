<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;
use Inertia\Inertia;
use Laravel\Fortify\Features;
use Illuminate\Foundation\Auth\EmailVerificationRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

use App\Models\User;

use App\Http\Controllers\WalletController;
use App\Http\Controllers\DepositController;
use App\Http\Controllers\WithdrawalController;
use App\Http\Controllers\TransactionController;
use App\Http\Controllers\BankAccountController;
use App\Http\Controllers\CardController;
use App\Http\Controllers\LoanController;
use App\Http\Controllers\CopiedTradeController;
use App\Http\Controllers\CopyTradeHistoryController;
use App\Http\Controllers\CopyRelationshipController;
use App\Http\Controllers\AdminTransactionController;
use App\Http\Controllers\AdminUserController;
use App\Http\Controllers\AdminSecurityStepController;
use App\Http\Controllers\SecurityVerificationController;


/*
|--------------------------------------------------------------------------
| AUTH PAGES (Inertia)
|--------------------------------------------------------------------------
*/

// Login must be guest-only
Route::middleware('guest')->get('/login', fn () =>
    Inertia::render('auth/Login')
)->name('login');

// Register MUST be accessible even if logged in
Route::get('/register', fn () =>
    Inertia::render('auth/Register')
)->name('register');

/*
|--------------------------------------------------------------------------
| REGISTRATION (NO AUTO LOGIN)
|--------------------------------------------------------------------------
*/

Route::post('/register', function (Request $request) {

    $request->validate([
        'name' => ['required', 'string', 'max:255'],
        'email' => ['required', 'email', 'max:255', 'unique:users,email'],
        'password' => ['required', 'string', 'min:8', 'confirmed'],
        'account_type' => ['required', 'in:bank,broker,admin'],
    ]);

    $user = User::create([
        'name' => $request->name,
        'email' => $request->email,
        'password' => Hash::make($request->password),
        'account_type' => $request->account_type,
    ]);

    $user->sendEmailVerificationNotification();

    // 🔥 VERY IMPORTANT: prevent session confusion
    Auth::logout();

    return redirect()->route('login')->with(
        'status',
        'Account created successfully. Please login to verify your email.'
    );
});

/*
|--------------------------------------------------------------------------
| LOGIN / LOGOUT (Fortify)
|--------------------------------------------------------------------------
*/

Route::post('/login', [
    \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::class,
    'store'
]);

Route::post('/logout', [
    \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::class,
    'destroy'
])->middleware('auth')->name('logout');

/*
|--------------------------------------------------------------------------
| EMAIL VERIFICATION
|--------------------------------------------------------------------------
*/

Route::get('/verify/email', fn () =>
    Inertia::render('auth/VerifyEmail')
)->middleware('auth')->name('verification.notice');

Route::get('/verify/email/{id}/{hash}', function (EmailVerificationRequest $request) {
    $request->fulfill();

    return match ($request->user()->account_type) {
        'bank' => redirect()->route('banking.dashboard'),
        'broker' => redirect()->route('broker.dashboard'),
        'admin' => redirect()->route('admin.dashboard'),
        default => redirect()->route('home'),
    };
})->middleware(['auth', 'signed'])->name('verification.verify');

Route::post('/email/verification-notification', function (Request $request) {
    $request->user()->sendEmailVerificationNotification();
    return back();
})->middleware(['auth', 'throttle:6,1'])->name('verification.send');

/*
|--------------------------------------------------------------------------
| PUBLIC PAGES
|--------------------------------------------------------------------------
*/

Route::get('/', fn () => Inertia::render('Welcome', [
    'canRegister' => Features::enabled(Features::registration()),
]))->name('home');

Route::get('/about', fn () => Inertia::render('About'))->name('about');
Route::get('/faq', fn () => Inertia::render('Faq'))->name('faq');
Route::get('/trade', fn () => Inertia::render('TradeView'))->name('trade');
Route::get('/pricing', fn () => Inertia::render('Pricing'))->name('pricing');
Route::get('/contact', fn () => Inertia::render('Contact'))->name('contact');
Route::get('/markets', fn () => Inertia::render('Markets'))->name('markets');

Route::get('/markets/{symbol}', fn ($symbol) =>
    Inertia::render('MarketProfile', ['symbol' => $symbol])
)->name('market.profile');

/*
|--------------------------------------------------------------------------
| AUTHENTICATED JSON ENDPOINTS (Axios)
|--------------------------------------------------------------------------
*/

Route::middleware(['auth', 'verified'])->group(function () {

    Route::get('/user', fn (Request $request) => $request->user());

    Route::get('/wallets', [WalletController::class, 'index']);
    Route::post('/withdraw', [WalletController::class, 'withdraw']); 
    
    Route::get('/security-steps', [SecurityVerificationController::class, 'index']);
    Route::post('/security-steps/{step}/verify', [SecurityVerificationController::class, 'verify']);

    Route::get('/deposits', [DepositController::class, 'index']);
    Route::post('/deposits', [DepositController::class, 'store']);

    Route::get('/withdrawals', [WithdrawalController::class, 'index']);
    Route::post('/withdrawals', [WithdrawalController::class, 'store']);

    Route::get('/transactions', [TransactionController::class, 'index']);

    Route::get('/cards', [CardController::class, 'index']);
    Route::post('/cards', [CardController::class, 'store']);

    Route::get('/loans', [LoanController::class, 'index']);
    Route::post('/loans', [LoanController::class, 'store']);
});

/*
|--------------------------------------------------------------------------
| BANK DASHBOARD
|--------------------------------------------------------------------------
*/

Route::middleware(['auth', 'verified', 'role:bank'])
    ->prefix('bank')->name('banking.')
    ->group(function () {
        Route::get('dashboard', fn () => Inertia::render('banking/Dashboard'))->name('dashboard');
        Route::get('wallet', fn () => Inertia::render('banking/Wallet'))->name('wallet');
        Route::get('deposit', fn () => Inertia::render('banking/Deposit'))->name('deposit');
        Route::get('withdraw', fn () => Inertia::render('banking/Withdraw'))->name('withdraw');
    });

/*
|--------------------------------------------------------------------------
| BROKER DASHBOARD
|--------------------------------------------------------------------------
*/

Route::middleware(['auth', 'verified', 'role:broker'])
    ->prefix('broker')->name('broker.')
    ->group(function () {
        Route::get('dashboard', fn () => Inertia::render('broker/Dashboard'))->name('dashboard');
    });

/*
|--------------------------------------------------------------------------
| ADMIN DASHBOARD
|--------------------------------------------------------------------------
*/

Route::middleware(['auth', 'verified', 'role:admin'])
    ->prefix('admin')->name('admin.')
    ->group(function () {

        Route::get('dashboard', fn () => Inertia::render('admin/Dashboard'))->name('dashboard');

        Route::get('users', [AdminUserController::class, 'index']);
        Route::post('users/credit', [AdminTransactionController::class, 'credit']);
        Route::post('users/deduct', [AdminTransactionController::class, 'deduct']);
        Route::get('security-steps', [SecurityStepController::class, 'index']);
        
        
    Route::post('security-steps', [SecurityStepController::class, 'store']);
    Route::put('security-steps/{securityStep}', [SecurityStepController::class, 'update']);
    Route::delete('security-steps/{securityStep}', [SecurityStepController::class, 'destroy']);
    });


// Modular settings
require __DIR__.'/settings.php';